import cv2


image = cv2.imread("sample.jpg")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
_, threshold = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY_INV)

contours, _ = cv2.findContours(
    threshold,
    cv2.RETR_EXTERNAL,
    cv2.CHAIN_APPROX_SIMPLE,
)

all_contours_image = image.copy()
biggest_contour_image = image.copy()
if contours:
    cv2.drawContours(all_contours_image, contours, -1, (255, 0, 0), 2)

    biggest_contour = max(contours, key=cv2.contourArea)
    cv2.drawContours(biggest_contour_image, [biggest_contour], -1, (0, 255, 0), 2)
else:
    print("No contours found")

cv2.imshow("Sample Image", image)
cv2.imshow("All Contours", all_contours_image)
cv2.imshow("Biggest Contour", biggest_contour_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

    _, thresh = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY_INV)
